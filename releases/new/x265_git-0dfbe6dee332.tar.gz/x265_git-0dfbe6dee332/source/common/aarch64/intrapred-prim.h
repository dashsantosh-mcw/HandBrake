#ifndef INTRAPRED_PRIM_H__

#if defined(__aarch64__)

namespace X265_NS
{
// x265 private namespace

void setupIntraPrimitives_neon(EncoderPrimitives &p);
}

#endif

#endif

